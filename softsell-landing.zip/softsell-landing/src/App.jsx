
import React from "react";
import { useState } from "react";

export default function App() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    licenseType: "",
    message: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Form submitted successfully!");
  };

  return (
    <main className="font-sans text-gray-800">
      <section className="bg-blue-600 text-white p-10 text-center">
        <h1 className="text-4xl font-bold mb-2">Resell Unused Software Licenses Easily</h1>
        <p className="mb-4">Turn idle software assets into cash in minutes.</p>
        <button className="bg-white text-blue-600 px-6 py-2 rounded font-semibold">
          Sell My Licenses
        </button>
      </section>

      <section className="p-10 text-center bg-gray-50">
        <h2 className="text-3xl font-semibold mb-6">How It Works</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { title: "Upload License", icon: "📤" },
            { title: "Get Valuation", icon: "💰" },
            { title: "Get Paid", icon: "🏦" },
          ].map((step, index) => (
            <div key={index} className="p-4 bg-white rounded shadow">
              <div className="text-5xl mb-2">{step.icon}</div>
              <h3 className="text-xl font-medium">{step.title}</h3>
            </div>
          ))}
        </div>
      </section>

      <section className="p-10 bg-white text-center">
        <h2 className="text-3xl font-semibold mb-6">Why Choose Us</h2>
        <div className="grid md:grid-cols-4 gap-4">
          {[
            { title: "Fast Payments", icon: "⚡" },
            { title: "Best Market Rates", icon: "📈" },
            { title: "Secure Process", icon: "🔒" },
            { title: "24/7 Support", icon: "🕐" },
          ].map((feature, index) => (
            <div key={index} className="p-4 bg-gray-50 rounded shadow">
              <div className="text-4xl mb-2">{feature.icon}</div>
              <h3 className="font-medium text-lg">{feature.title}</h3>
            </div>
          ))}
        </div>
      </section>

      <section className="p-10 bg-gray-100 text-center">
        <h2 className="text-3xl font-semibold mb-6">What Our Clients Say</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {[
            {
              text: "SoftSell helped us recover value from unused tools effortlessly!",
              name: "Alex Carter",
              role: "IT Manager",
              company: "TechNova Inc.",
            },
            {
              text: "Smooth process and quick payouts. Highly recommended!",
              name: "Rina Patel",
              role: "Operations Head",
              company: "CloudCore Solutions",
            },
          ].map((review, index) => (
            <div key={index} className="p-6 bg-white rounded shadow">
              <p className="italic mb-4">“{review.text}”</p>
              <p className="font-semibold">{review.name}</p>
              <p className="text-sm text-gray-600">
                {review.role}, {review.company}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="p-10 bg-white text-center">
        <h2 className="text-3xl font-semibold mb-6">Get in Touch</h2>
        <form
          onSubmit={handleSubmit}
          className="max-w-xl mx-auto text-left grid gap-4"
        >
          <input
            type="text"
            name="name"
            placeholder="Name"
            value={formData.name}
            onChange={handleChange}
            required
            className="border p-2 rounded w-full"
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
            required
            className="border p-2 rounded w-full"
          />
          <input
            type="text"
            name="company"
            placeholder="Company"
            value={formData.company}
            onChange={handleChange}
            required
            className="border p-2 rounded w-full"
          />
          <select
            name="licenseType"
            value={formData.licenseType}
            onChange={handleChange}
            required
            className="border p-2 rounded w-full"
          >
            <option value="">Select License Type</option>
            <option value="Windows">Windows</option>
            <option value="Office">Office</option>
            <option value="Adobe">Adobe</option>
            <option value="Other">Other</option>
          </select>
          <textarea
            name="message"
            placeholder="Message"
            value={formData.message}
            onChange={handleChange}
            required
            className="border p-2 rounded w-full"
          />
          <button
            type="submit"
            className="bg-blue-600 text-white px-6 py-2 rounded font-semibold"
          >
            Submit
          </button>
        </form>
      </section>
    </main>
  );
}
